import React from 'react';
import PropTypes from 'prop-types';

Loading.propTypes = {
    
};

function Loading(props) {
    return (
        <div>
            Loading
        </div>
    );
}

export default Loading;